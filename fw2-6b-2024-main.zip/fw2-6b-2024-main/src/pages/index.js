function Index(){
    return <h1>Olá Mundo</h1>
}
export default Index;