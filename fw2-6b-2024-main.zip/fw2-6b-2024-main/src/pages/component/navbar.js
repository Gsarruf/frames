export default function Navbar() {
    return <div>Menu</div>
}
