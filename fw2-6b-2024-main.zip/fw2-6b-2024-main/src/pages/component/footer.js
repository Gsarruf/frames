export default function Footer() {
    return <div>IFMS-Dourados</div>
}
